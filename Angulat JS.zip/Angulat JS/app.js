var app = angular.module("practice", []);
