'use strict'

angular.module('practice').controller("studentCon" , function($scope){
	
	$scope.saveStudentForm=function(){
		$scope.mobileNumber=/^\+?\d{2}[- ]?\d{3}[- ]?\d{5}$/;
		alert(student.password);
		alert($scope.password);
		$scope.studentName
		
	}


});